import React, { createContext, useState } from "react";

export const CartContext = createContext([]);

const CartContextProvider = ({ children }) => {
  const [carts, setCarts] = useState([]);
  const [total, setTotal] = useState(0);
    const addToCart = (cart) => {
    setCarts([...carts, {...cart, totalPrice : cart.price}]);
    setTotal((prev)=> prev +cart.price )
  };
  // console.log(carts,"carts")
  const deleteFromCart = (itemId) => {
    const remainingItems = carts.filter((cart) => cart.id != itemId);
    setCarts(remainingItems);
  };
  const getTotalPrice = ()=> {
   const totalPriceSum = carts.reduce((sum, cart) => sum + cart.totalPrice, 0);
   return totalPriceSum
  }

  return (
    <CartContext.Provider
      value={{ carts, addToCart, deleteFromCart, setCarts,total, setTotal,getTotalPrice }}
    >
      {children}
    </CartContext.Provider>
  );
};

export default CartContextProvider;
