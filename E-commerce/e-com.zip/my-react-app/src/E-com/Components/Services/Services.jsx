import React, { useState } from 'react'
import "./services.css";
const BeBot = () => {
    const BData=[
        {
            id:1,
            hea:"worldwide Delivery",
            image:"https://cdn-icons-png.flaticon.com/512/9242/9242675.png",
            para:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur quae "
        },
        {
            id:2,
            hea:"Safe Payment",
            image:"https://cdn-icons-png.flaticon.com/512/5711/5711557.png",
            para:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur quae "
        },
        {
            id:3,
            hea:"Shop With Confidence",
            image:"https://cdn-icons-png.flaticon.com/512/46/46887.png",
            para:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur quae "
        },
        {
            id:4,
            hea:"24/7 Support",
            image:"https://cdn-icons-png.flaticon.com/512/3249/3249904.png",
            para:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur quae "
        },
    ]
    const [dat,setDat]=useState(BData)
    return (
    <div className='flexy'>
      {dat.map((e,ind)=>{
        const{id,image,para,hea}=e
        return(
            <div className='main' key={ind}>
                <div className='imi'>
                    <img className='bim' src={image} alt="" />
                </div>
                <h5 className='he'><b>{hea}</b></h5>
                <p className='Bpara'>{para}</p>
                
            </div>
        )
      })}
    </div>
  )
}

export default BeBot
