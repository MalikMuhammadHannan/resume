import React, { createContext, useState } from "react";

export const CartContext = createContext([]);

const CartContextProvider = ({ children }) => {
  const [carts, setCarts] = useState([]);
  const addToCart = (cart) => {
    setCarts([...carts, cart]);
  };
  const deleteFromCart = (itemId) => {
    const remainingItems = carts.filter((cart) => cart.id != itemId);
    setCarts(remainingItems);
  };
  return (
    <CartContext.Provider
      value={{ carts, addToCart, deleteFromCart, setCarts }}
    >
      {children}
    </CartContext.Provider>
  );
};

export default CartContextProvider;
