import React from "react";

import Main_app from "./e-commerce/Main_app";
import CartContextProvider from "./Context/CartContext";
const HeadMain = () => {
  return (
    <div>
      <CartContextProvider>
        <Main_app />
      </CartContextProvider>
    </div>
  );
};

export default HeadMain;
