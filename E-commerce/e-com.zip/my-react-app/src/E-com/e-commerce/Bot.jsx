import React from "react";
import "./Bot.css";
const Bot = () => {
  return (
      <div>

    
    <div className="swBflexB">
      <div className="swlb">
        <h4 className="swBH4">Own way</h4>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Et
          dignissimos repellat tempore deleniti deserunt modi dolore velit
          accusamus iure sed?
        </p>
      </div>
      <div className="swlrb">
        <h4 className="swBH4">About Us</h4>
        <h5 className="swBHB">Carrers</h5>
        <h5 className="swBHB">Terms & Condition</h5>
        <h5 className="swBHB">Privacy Policy</h5>
      </div>
      <div className="swrrb">
        <h4 className="swBH4">Help Center</h4>
        <h5 className="swBHB">How To Buy</h5>
        <h5 className="swBHB">Track Your Order</h5>
        <h5 className="swBHB">Corporate & Bulk Purchasing</h5>
        <h5 className="swBHB">Return & Refund</h5>
      </div>
      <div className="swrb">
        <h4 className="swBH4">Contact Us</h4>
        <h5 className="swBHB">70 Washington Square South, New York, NY 10012,United States</h5>
        <h5 className="swBHB">Email: hannanmalik228@gmail.com</h5>
        <h5 className="swBHB">Phone: +12 1234567891</h5>
      </div>
    </div>
      <footer className="swbot_foot">
        <p className="swfp">
            copyright © {new Date().getFullYear()} All Rights Reserved
        </p>
      </footer>
      </div>
  );
};

export default Bot;
