import { Button } from '@mui/material'
import React from 'react'
// import { Link } from "react-router-dom";
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import "./L_header.css"
import { NavLink } from 'react-router-dom';
const Header = () => {
  return (
    <div className='swflex swhht'>
     <div className='swhhi'>
      <NavLink to="/" >
        <Button className='swhhi'><ArrowBackIcon className='swhhi'/></Button>
      </NavLink>
      
     </div>
     <div>
      <h2 className='swhhht'>Own Way</h2>
     </div>
    </div>
  )
}

export default Header
