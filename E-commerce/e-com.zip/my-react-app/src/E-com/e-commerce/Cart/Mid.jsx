import Api from "../Api";
import React, { useContext, useState } from "react";
import "./Mid.css";
import DeleteIcon from "@mui/icons-material/Delete";
import RemoveIcon from "@mui/icons-material/Remove";
import AddIcon from "@mui/icons-material/Add";
import Button from "@mui/material/Button";
import CartItem from "../../Components/CartItem/CartItem";
import { CartContext } from "../../Context/CartContext";
const Mid = () => {
  const [Mydata, setMydata] = useState(Api);
  const {carts,deleteFromCart} = useContext(CartContext)
  return (
    <div>
      {carts.map((m) => {
        const { title, price, image, id } = m;
        return (
          <CartItem
            key={id}
            image={image}
            price={price}
            title={title}
            deleteItem={()=> deleteFromCart(id)}
          />
          
        );
      })}
    </div>
  );
};

export default Mid;
