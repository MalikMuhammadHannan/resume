import React from "react";
import L_header from "./L_header";
import Mid from "./Mid";
import Total from "./Total";
import "./Mid.css"
const AddCart = () => {
  return (
    <div>
      <L_header />
      <div className=" swaddFlex">
        <Mid className="swmidW" />
        <Total className="swtotalW" />
      </div>
    </div>
  );
};

export default AddCart;
