// import "../img"
const Data = [
  //iphone
  {
    id: 1,
    title: "iphone 7",
    image: "./img/7.png",
    category: "iphone",
    price: "500",
  },
  {
    id: 2,
    title: "iphone 8",
    image: "./img/i8.png",
    category: "iphone",
    price: "900",
  },
  {
    id: 3,
    title: "iphone x",
    image: "./img/8.png",
    category: "iphone",
    price: "1000",
  },
  {
    id: 4,
    title: "iphone 13",
    image: "./img/13.png",
    category: "iphone",
    price: "1200",
  },
  // samsung
  {
    id: 5,
    title: "samsung Galaxy S22",
    image: "./img/22ultra.png",
    category: "samsung",
    price: "400",
  },
  {
    id: 6,
    title: "samsung Galaxy Z Fold 4",
    image: "./img/1flip.png",
    category: "samsung",
    price: "400",
  },
  {
    id: 7,
    title: "samsung Galaxy Z Flip 4",
    image: "./img/flip.png",
    category: "samsung",
    price: "400",
  },
  {
    id: 8,
    title: "samsung Galaxy S22 Plus",
    image: "./img/22plus.png",
    category: "samsung",
    price: "400",
  },
  //OPPO
  {
    id: 9,
    title: "OPPO Reno 9 Pro Plus",
    image: "./img/reno9pro.png",
    category: "oppo",
    price: "400",
  },
  {
    id: 10,
    title: "Oppo Find X5 Pro",
    image: "./img/x5pro.png",
    category: "oppo",
    price: "400",
  },
  {
    id: 11,
    title: "Oppo Reno 8 Pro",
    image: "./img/reno8.png",
    category: "oppo",
    price: "400",
  },
  {
    id: 12,
    title: "Oppo A96",
    image: "./img/a96.png",
    category: "oppo",
    price: "400",
  },
  //vivo
  {
    id: 13,
    title: "Vivo Slider Phone",
    image: "./img/vy51.png",
    category: "vivo",
    price: "400",
  },
  {
    id: 14,
    title: "Vivo S7 5G",
    image: "./img/vs7.png",
    category: "vivo",
    price: "400",
  },
  {
    id: 15,
    title: "Vivo S6",
    image: "./img/vs6.png",
    category: "vivo",
    price: "400",
  },
  {
    id: 16,
    title: "Vivo V20 SE",
    image: "../img/v20.png",
    category: "vivo",
    price: "400",
  },
];
export default Data