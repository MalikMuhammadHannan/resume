import React,{useState} from "react";
// import Button from "@mui/material/Button";
import "./LCard.css";
import Data from "./Data";
import BCard from "./BCard";
const LCard = () => {
  const [BData, setBData] = useState(Data);
  const filterd = (category) => {
    const update = Data.filter((cur) => {
      return cur.category === category;
    });
    setBData(update);
  };
  return (
    <div className="swXC">
      <div className="swLFlex">
        <div>
          <h3 className="swLCH3">
            <b>Brands</b>
          </h3>
        </div>
        <div>
          <button className="swLCH" onClick={() => filterd("iphone")}>
            Apple
          </button>
          <button className="swLCH" onClick={() => filterd("samsung")}>
            Samsung
          </button>
          <button className="swLCH" onClick={() => filterd("oppo")}>
            Oppo
          </button>
          <button className="swLCH" onClick={() => filterd("vivo")}>
            Vivo
          </button>
          <button className="swLCH All" onClick={() => setBData(Data)}>
            All
          </button>
        </div>
      </div>
      <div>
        <BCard BData={BData} />
      </div>
    </div>
  );
};

export default LCard;
