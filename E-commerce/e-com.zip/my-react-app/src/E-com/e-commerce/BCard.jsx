import React, { useContext } from "react";
// import Data from './Data'
import "./Card.css";
import AddIcon from "@mui/icons-material/Add";
import Button from "@mui/material/Button";
import { CartContext } from "../Context/CartContext";
const BCard = ({ BData }) => {
  const { addToCart } = useContext(CartContext);
  return (
    <div>
      <h2 className="swHaH2">
        <b>Mobile Phone</b>
      </h2>
      {
        <div className="swflex gap-4 swBCar">
          {BData.map((e, index) => {
            const { title, price, category, image } = e;
            return (
              <div className="swcard swBcard" key={index}>
                <img className="swuni_img" src={image} alt={category} />
                <h6 className="swuni_h6">{title}</h6>
                <div className="swbottom">
                  <h5 className="swuni_h5">
                    <b>${price}</b>
                  </h5>
                  <div className="swbty">
                    <Button
                      onClick={() => {
                        addToCart(e);
                      }}
                    >
                      <AddIcon />
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      }
    </div>
  );
};

export default BCard;
