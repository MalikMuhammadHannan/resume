import React from "react";

import AddCart from "./Cart/AddCart";
import { Route, Routes } from "react-router-dom";

import E_home from "../Pages/E_home";
const Main_app = () => {
  return (
    <>
      <Routes>
        <Route path="/" Component={E_home}/>
        <Route path="/cart" Component={AddCart}/>
      </Routes>
    </>
  );
};

export default Main_app;