import React from "react";
import SearchIcon from "@mui/icons-material/Search";
import Button from "@mui/material/Button";
import PersonIcon from "@mui/icons-material/Person";
import "./HeaOne.css";
import { Link } from "react-router-dom";
import AddShoppingCartIcon from "@mui/icons-material/AddShoppingCart";
const HeaOne = () => {
  return (
    <div className="swnav">
      <div>
        <h2 className="swHeH">OwnWay</h2>
      </div>
      <div className="swinp">
        <div>
          <input className="swHeaInput" type="text" placeholder="Search..." />
        </div>

        <Button>
          <SearchIcon />
        </Button>
      </div>
      <div className="swbt">
        <div className="swbtx">
          <Link to="/">
            <Button>
              <PersonIcon className="swicon" />
            </Button>
          </Link>
        </div>
        <Link to="/cart">
          <Button>
            <AddShoppingCartIcon className="swicon" />
          </Button>
        </Link>
      </div>
    </div>
  );
};

export default HeaOne;
