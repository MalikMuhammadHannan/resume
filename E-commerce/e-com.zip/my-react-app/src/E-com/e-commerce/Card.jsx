import React from "react";
import Card2 from "./Card2";
import Card1 from "./Card1";
import Card3 from "./Card3";
import Card5 from "./Card5";
import BCard from "./BCard";
import LCard from "./LCard";
import Services from "../Components/Services/Services";
import "./Card.css";
const Card = () => {
  return (
    <div>
      <div className="swdes">
        <img
          className="swim"
          src="https://shopp-marts.netlify.app/img/light.png"
          alt="flash"
        />
        <h2 className="swhd">Flash Deals</h2>
      </div>
      <Card1 />
      <div className="swdes">
        <img
          className="swim"
          src="https://shopp-marts.netlify.app/img/elecro.png"
          alt="flash"
        />
        <h2 className="swhd">Electronics Deals</h2>
      </div>
      <Card2 />
      <div className="swdes">
        <img
          className="swim"
          // src="https://shopp-marts.netlify.app/img/light.png"
          src="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Ftse1.mm.bing.net%2Fth%3Fid%3DOIP.6kQT8g-zYFAiB2F0uYNPKwAAAA%26pid%3DApi&f=1&ipt=dbd812b5df58e270e61b38d8ee0ecd701a4c8a8a8d7f2bde428ed9fc04c9b29a&ipo=images"
          alt="flash"
        />

        <h2 className="swhd">New Arrivals</h2>
      </div>
      <Card3 />
      <div className="swdes ">
        <img
          className="swim bds"
          src="https://shopp-marts.netlify.app/img/off.png
"
          alt="flash"
        />
        <h2 className="swhd">Big Discount</h2>
      </div>
      <Card5 />

      <LCard />
      <Services/>
    </div>
  );
};

export default Card;
