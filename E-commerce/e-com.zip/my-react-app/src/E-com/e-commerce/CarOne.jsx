import "bootstrap/dist/css/bootstrap.min.css";
import React from "react";
import { Carousel } from "react-bootstrap";
import "./CarOne.css";
const CarOne = () => {
  return (
    <div>
      <Carousel variant="dark">
        <Carousel.Item>
          <img
            className=" swimg "
            src="https://img.freepik.com/premium-vector/hand-drawn-illustration-people-shopping-sale_52683-55420.jpg?w=2000"
            alt="First slide"
          />
        </Carousel.Item>
        <Carousel.Item>
          <img
            className=" swimg"
            src="https://img.freepik.com/free-vector/flat-hand-drawn-people-holding-shopping-bags_23-2148845329.jpg?w=740&t=st=1680646731~exp=1680647331~hmac=375d0490ca5150e06b387a05d78867d09d1a4f006dcef52accd5744d52d7f4ce"
            alt="Second slide"
          />
        </Carousel.Item>
        <Carousel.Item>
          <img
            className=" swimg"
            src="https://img.freepik.com/premium-vector/people-run-sale-shopping-isolated-white-background-excited-male-female-characters-hurry-buy-things_1016-13149.jpg?w=826"
            alt="Third slide"
          />
        </Carousel.Item>
      </Carousel>
    </div>
  );
};
export default CarOne;
