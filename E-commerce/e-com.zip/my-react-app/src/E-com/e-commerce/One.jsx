import React from "react";
import CarOne from "./CarOne";
import HeaOne from "./HeaOne";
import Card from "./Card";
import Bot from "./Bot";
const One = () => {
  return (
    <div>
      <HeaOne />
      <CarOne />
      <Card />
      <Bot/>
    </div>
  );
};

export default One;
