import React from "react";
import HeaOne from "../e-commerce/HeaOne";
import CarOne from "../e-commerce/CarOne";
import Card from "../e-commerce/Card";
import Bot from "../e-commerce/Bot";

const E_home = () => {
  return (
    <div>
      <HeaOne />
      <CarOne />
      <Card />
      <Bot/>
    </div>
  );
};

export default E_home;
