import React from "react";
import App from "./e-commerce/Main_app";
import ReactDOM from "react-dom/client";
import One from "./e-commerce/One";
import { BrowserRouter } from "react-router-dom";
import CartContextProvider from "./Context/CartContext";
import HeadMain from "./HeadMain";
ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <BrowserRouter>
      <HeadMain />
    </BrowserRouter>
  </React.StrictMode>
);
