import Api from "../Api";
import React, { useContext, useState } from "react";
import "./Mid.css";
import DeleteIcon from "@mui/icons-material/Delete";
import RemoveIcon from "@mui/icons-material/Remove";
import AddIcon from "@mui/icons-material/Add";
import Button from "@mui/material/Button";
import CartItem from "../../Components/CartItem/CartItem";
import { CartContext } from "../../Context/CartContext";
const Mid = () => {
  const [Mydata, setMydata] = useState(Api);
  const {carts, setCarts, deleteFromCart, total, setTotal} = useContext(CartContext)
  // console.log(total, "setTotal")
  return (
    <div>
      {carts?.map((m) => {
        const { title, price, image, id, totalPrice } = m;
        return (
          <CartItem
            key={id}
            id={id}
            image={image}
            price={price}
            title={title}
            deleteItem={()=> deleteFromCart(id)}
            total={total}
            setTotal={ setTotal}
            totalPrice={totalPrice}
            setCarts={setCarts}
          />
          
        );
      })}
    </div>
  );
};

export default Mid;
