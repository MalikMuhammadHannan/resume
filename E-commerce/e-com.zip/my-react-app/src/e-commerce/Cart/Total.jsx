import { Button } from "@mui/material";
import React, { useContext, useEffect, useState } from "react";
import CancelIcon from "@mui/icons-material/Cancel";
import { useNavigate } from "react-router-dom";

import "./Mid.css";
import Modal from "react-modal";
import { CartContext } from "../../Context/CartContext";
const Total = () => {
  const navigate = useNavigate();
  const [modalOpen, setModalOpen] = useState(false);
  const { setTotal, addToCart, setCarts,carts,getTotalPrice } = useContext(CartContext);

  const total =  getTotalPrice();

  // console.log(total,'total')

  return (
    <div className="swtotal">
      <h4>Total</h4>
      <h4>$ {Math.round(total)}</h4>
      <div className="swtotalbtn">
        <Button type="button" onClick={() => setModalOpen(true)}>
          Place Order
        </Button>
        <Modal
          isOpen={modalOpen}
          className="swmodall"
          //  onRequestClose={()=>setModalOpen(false)}
        >
          <div className="swclose">
            <Button className="swclose" onClick={() => setModalOpen(false)}>
              <CancelIcon />
            </Button>
          </div>
          <div className="swmmid">
            <h3>Information</h3>
            <input className="swMinput" type="text" placeholder="Your Name" required />
            <input
              className="swMinput"
              type="address"
              placeholder="Enter Address"
            />
            <input className="swMinput" type="email" placeholder="Enter Email" />
          </div>
          <div className="swalebtn">
            <Button
              className="swalebtn"
              type="submit"
              onClick={() => {
                alert("Order Placed Successfully");
                setModalOpen(false);
                navigate("/");
                // setCarts([]);
              }}
            >
              Confirm
            </Button>
          </div>
          <p className="swMpa">* Note : No online paayment accepted.</p>
        </Modal>
      </div>
    </div>
  );
};

export default Total;
