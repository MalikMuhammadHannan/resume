import React, { useContext, useEffect, useState } from 'react';

import DeleteIcon from "@mui/icons-material/Delete";
import RemoveIcon from "@mui/icons-material/Remove";
import AddIcon from "@mui/icons-material/Add";
import Button from "@mui/material/Button";
import { CartContext } from '../../Context/CartContext';

const CartItem = ({ id, image, title, price, deleteItem, total, totalPrice, setTotal, setCarts }) => {
  const [quantity, setQuantity] = useState(1);
  useEffect(() => {
    setCarts((pre) => {
      const updateData = pre.map((elem) => {

        if (elem.id === id) return { ...elem, totalPrice: elem.price * quantity }
        return elem

      })

      return updateData
    })
  }, [quantity, id])
  return (
    <div className="swmid">

      <div>
        <img className="swmidim" src={image} alt={title} />
      </div>
      <div>
        <p className="swmidh6">{title}</p>
      </div>
      <div className="swmidc">
        <div className="swadd">
          <Button className="swmidbtn" onClick={() => { setQuantity(quantity + 1); }} >
            <AddIcon className="swmidbtn" />
          </Button>
        </div>
        <input className='swcartInput' type="number" value={quantity} />
        <div className="swadd">
          <Button className="swmidbtn" onClick={() => { if (setQuantity > 1) { setQuantity(quantity - 1) } else { setQuantity(1) } }} >
            <RemoveIcon className="swmidbtn" />
          </Button>
        </div>
      </div>
      <div>
        <h6 className="swmidh5">${Math.round(price * quantity)}</h6>
      </div>
      <div>
        <Button className="swmidbtn" onClick={deleteItem}>
          <DeleteIcon className="swmidbtn" />
        </Button>
      </div>
    </div>
  )
}

export default CartItem